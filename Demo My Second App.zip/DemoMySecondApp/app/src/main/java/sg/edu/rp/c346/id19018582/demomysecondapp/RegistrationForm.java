package sg.edu.rp.c346.id19018582.demomysecondapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class RegistrationForm extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration_form);
    }
}
